package se.hig.oodp.lab.control;

public interface FigurePrinter
{
	public void printAll();
}
