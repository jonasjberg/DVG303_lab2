package se.hig.oodp.lab.control;

public interface FigureRotor
{
	public void rotateAll(double angle);
}
