package se.hig.oodp.lab.control;

public interface FigureMover
{
	public void moveAll(double dx, double dy);
}
