package se.hig.oodp.lab.control;

public interface FigureScalor
{
	public void scaleAll(double factor_x, double factor_y);
}
